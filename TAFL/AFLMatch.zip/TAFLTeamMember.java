package TAFL;

public class TAFLTeamMember {

    private String firstName;
    private String lastName;
    private String position;

    public TAFLTeamMember(String firstName, String lastName, String position) {
        this.firstName = firstName;
        this.lastName = lastName;
        setPosition(position);
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        if (isValidPosition(position)) {
            this.position = position;
        } else {
            System.out.println("Invalid position: " + position);
        }
    }

    private boolean isValidPosition(String position) {
        String[] validPositions = {"FB", "HB", "C", "HF", "FF", "FOL", "IC", "COACH"};
        for (String validPosition : validPositions) {
            if (validPosition.equals(position)) {
                return true;
            }
        }
        return false;
    }

    public String toString() {
        return firstName + " " + lastName + "," + position;
    }

    public static void main(String[] args) {
        TAFLTeamMember player1 = new TAFLTeamMember("Tom", "Mitchell", "C");
        TAFLTeamMember player2 = new TAFLTeamMember("Dylan", "Grimes", "HB");
        TAFLTeamMember coach = new TAFLTeamMember("Damien", "Hardwick", "COACH");
    
        System.out.println(player1.toString());
        System.out.println(player2);
        System.out.println(coach);

    }
}


