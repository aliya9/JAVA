

public class Suffix
{
    public static void main(String args[])
    
    {
        RegularPolygon r = new RegularPolygon(0, 0); //Instance of class RegularPolygon
        r.getSides();
        r.getsideLength();
        r.computeArea();
    }
    
}
